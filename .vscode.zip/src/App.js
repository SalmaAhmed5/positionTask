import "./App.css";
import "./index.css";
import Home from "./pages";
function App() {
  return (
    <div className="App container mx-auto my-auto max-w-[1000px] ">
      <Home />
    </div>
  );
}

export default App;
